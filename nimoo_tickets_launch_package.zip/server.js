require("dotenv").config();
const express=require("express"),session=require("express-session"),SQLiteStore=require("connect-sqlite3")(session);
const Database=require("better-sqlite3"),bcrypt=require("bcryptjs"),helmet=require("helmet"),rateLimit=require("express-rate-limit"),QR=require("qrcode"),crypto=require("crypto");
const app=express(),db=new Database("nimoo.db");
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"30kb"}));
app.use(express.urlencoded({extended:false}));
app.use(session({store:new SQLiteStore({db:"sessions.db"}),secret:process.env.SESSION_SECRET||"development-only-change-me",resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}}));
app.use(express.static("public"));
db.exec(`
CREATE TABLE IF NOT EXISTS admins(id INTEGER PRIMARY KEY, username TEXT UNIQUE, password_hash TEXT);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT NOT NULL,venue TEXT NOT NULL,event_date TEXT NOT NULL,price INTEGER NOT NULL,description TEXT DEFAULT '',active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,event_id INTEGER NOT NULL,buyer TEXT NOT NULL,phone TEXT NOT NULL,quantity INTEGER NOT NULL,total INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',checkout_request_id TEXT,mpesa_receipt TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(event_id) REFERENCES events(id));
CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY,order_id TEXT NOT NULL,event_id INTEGER NOT NULL,qr_token TEXT UNIQUE NOT NULL,used INTEGER DEFAULT 0,FOREIGN KEY(order_id) REFERENCES orders(id));
`);
const adminCount=db.prepare("SELECT COUNT(*) n FROM admins").get().n;
if(!adminCount && process.env.ADMIN_USERNAME && process.env.ADMIN_PASSWORD){
 db.prepare("INSERT INTO admins(username,password_hash) VALUES(?,?)").run(process.env.ADMIN_USERNAME,bcrypt.hashSync(process.env.ADMIN_PASSWORD,12));
}
if(db.prepare("SELECT COUNT(*) n FROM events").get().n===0){
 const seed=db.prepare("INSERT INTO events(title,category,venue,event_date,price,description) VALUES(?,?,?,?,?,?)");
 [
 ["Live Music Night","Music","Nairobi, Kenya","2026-11-21",1000,"An evening of live performances and great energy."],
 ["City Football Derby","Sports","Kasarani Stadium","2026-11-28",500,"Experience the match-day atmosphere."],
 ["Laugh Out Loud Show","Comedy","Westlands, Nairobi","2026-12-05",800,"A night of stand-up comedy."],
 ["Entrepreneurs Summit","Business","Nairobi, Kenya","2026-12-12",2500,"Connect, learn and grow."],
 ["Good Vibes Festival","Festival","Uhuru Gardens, Nairobi","2026-12-19",1200,"Music, food and culture."]
 ].forEach(x=>seed.run(...x));
}
const auth=(req,res,next)=>req.session.admin?next():res.status(401).json({error:"Sign in required"});
const limiter=rateLimit({windowMs:15*60*1000,limit:30,standardHeaders:true,legacyHeaders:false});
app.get("/api/events",(req,res)=>res.json(db.prepare("SELECT id,title,category,venue,event_date,price,description FROM events WHERE active=1 ORDER BY event_date").all()));
app.post("/api/admin/login",limiter,(req,res)=>{
 const row=db.prepare("SELECT * FROM admins WHERE username=?").get(String(req.body.username||""));
 if(!row||!bcrypt.compareSync(String(req.body.password||""),row.password_hash))return res.status(401).json({error:"Invalid login"});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:"Session error"});req.session.admin={id:row.id,username:row.username};res.json({ok:true})});
});
app.post("/api/admin/logout",auth,(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/admin/me",auth,(req,res)=>res.json({username:req.session.admin.username}));
app.get("/api/admin/orders",auth,(req,res)=>res.json(db.prepare(`SELECT o.*,e.title event_title FROM orders o JOIN events e ON e.id=o.event_id ORDER BY o.created_at DESC LIMIT 250`).all()));
app.post("/api/admin/events",auth,(req,res)=>{
 const {title,category,venue,event_date,price,description=""}=req.body;
 if(!title||!category||!venue||!event_date||!Number.isInteger(Number(price))||Number(price)<1)return res.status(400).json({error:"Complete all required fields with a valid ticket price"});
 const r=db.prepare("INSERT INTO events(title,category,venue,event_date,price,description) VALUES(?,?,?,?,?,?)").run(title,category,venue,event_date,Number(price),description);
 res.json({id:r.lastInsertRowid});
});
app.patch("/api/admin/events/:id",auth,(req,res)=>{
 const {active}=req.body;db.prepare("UPDATE events SET active=? WHERE id=?").run(active?1:0,req.params.id);res.json({ok:true});
});
function mpesaBase(){return process.env.MPESA_ENV==="production"?"https://api.safaricom.co.ke":"https://sandbox.safaricom.co.ke"}
async function mpesaToken(){
 const key=process.env.MPESA_CONSUMER_KEY,secret=process.env.MPESA_CONSUMER_SECRET;
 if(!key||!secret)throw new Error("M-Pesa credentials have not been configured");
 const basic=Buffer.from(key+":"+secret).toString("base64");
 const r=await fetch(mpesaBase()+"/oauth/v1/generate?grant_type=client_credentials",{headers:{Authorization:"Basic "+basic}});
 const j=await r.json();if(!r.ok||!j.access_token)throw new Error("Could not authenticate with Daraja");return j.access_token;
}
function phone254(p){let s=String(p).replace(/\D/g,"");if(s.startsWith("0"))s="254"+s.slice(1);if(s.startsWith("7")||s.startsWith("1"))s="254"+s;return /^254[17]\d{8}$/.test(s)?s:null}
app.post("/api/checkout",limiter,async(req,res)=>{
 try{
  const {eventId,name,phone,quantity}=req.body,q=Number(quantity),p=phone254(phone);
  const ev=db.prepare("SELECT * FROM events WHERE id=? AND active=1").get(Number(eventId));
  if(!ev||!name||name.length>100||!p||!Number.isInteger(q)||q<1||q>10)return res.status(400).json({error:"Check your details and ticket quantity (maximum 10)."});
  if(!process.env.MPESA_PASSKEY||!process.env.MPESA_SHORTCODE||!process.env.MPESA_TILL_NUMBER||!process.env.MPESA_CALLBACK_URL)return res.status(503).json({error:"M-Pesa is not activated yet. Please contact the event organiser."});
  const total=ev.price*q;if(total<1||total>250000)return res.status(400).json({error:"Order amount is outside supported limits."});
  const token=await mpesaToken(),timestamp=new Date().toISOString().replace(/[-T:.Z]/g,"").slice(0,14);
  const shortcode=process.env.MPESA_SHORTCODE, till=process.env.MPESA_TILL_NUMBER, passkey=process.env.MPESA_PASSKEY;
  const password=Buffer.from(shortcode+passkey+timestamp).toString("base64");
  const orderId=crypto.randomUUID();
  db.prepare("INSERT INTO orders(id,event_id,buyer,phone,quantity,total,status) VALUES(?,?,?,?,?,?,'PENDING')").run(orderId,ev.id,name,p,q,total);
  const payload={BusinessShortCode:shortcode,Password:password,Timestamp:timestamp,TransactionType:process.env.MPESA_TRANSACTION_TYPE||"CustomerBuyGoodsOnline",Amount:total,PartyA:p,PartyB:till,PhoneNumber:p,CallBackURL:process.env.MPESA_CALLBACK_URL,AccountReference:"NIM"+orderId.slice(0,8),TransactionDesc:"Nimoo Tickets"};
  const r=await fetch(mpesaBase()+"/mpesa/stkpush/v1/processrequest",{method:"POST",headers:{Authorization:"Bearer "+token,"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const j=await r.json();if(!r.ok||j.ResponseCode!=="0"){db.prepare("UPDATE orders SET status='FAILED' WHERE id=?").run(orderId);return res.status(502).json({error:j.errorMessage||j.ResponseDescription||"M-Pesa request failed"});}
  db.prepare("UPDATE orders SET checkout_request_id=? WHERE id=?").run(j.CheckoutRequestID,orderId);
  res.json({ok:true,message:"M-Pesa prompt sent. Enter your M-Pesa PIN on your phone to complete payment.",orderId});
 }catch(e){console.error(e.message);res.status(503).json({error:"Payment service is not ready. Please try again later."})}
});
app.post("/api/mpesa/callback",(req,res)=>{
 try{
  const cb=req.body?.Body?.stkCallback;if(!cb)return res.json({ResultCode:0,ResultDesc:"Accepted"});
  const order=db.prepare("SELECT * FROM orders WHERE checkout_request_id=?").get(cb.CheckoutRequestID);
  if(order&&order.status==="PENDING"&&cb.ResultCode===0){
   const items=cb.CallbackMetadata?.Item||[],receipt=items.find(x=>x.Name==="MpesaReceiptNumber")?.Value;
   if(receipt){db.prepare("UPDATE orders SET status='PAID',mpesa_receipt=? WHERE id=?").run(String(receipt),order.id);
    const ins=db.prepare("INSERT INTO tickets(id,order_id,event_id,qr_token) VALUES(?,?,?,?)");
    for(let i=0;i<order.quantity;i++){const tid=crypto.randomUUID(),token=crypto.randomBytes(24).toString("hex");ins.run(tid,order.id,order.event_id,token);}
   }
  }else if(order){db.prepare("UPDATE orders SET status='FAILED' WHERE id=?").run(order.id)}
  res.json({ResultCode:0,ResultDesc:"Accepted"});
 }catch(e){console.error("Callback error",e);res.json({ResultCode:0,ResultDesc:"Accepted"})}
});
app.get("/api/order/:id",async(req,res)=>{
 const o=db.prepare("SELECT o.id,o.status,o.total,o.quantity,e.title event_title FROM orders o JOIN events e ON e.id=o.event_id WHERE o.id=?").get(req.params.id);
 if(!o)return res.status(404).json({error:"Order not found"});
 if(o.status==="PAID"){
  const ts=db.prepare("SELECT id,qr_token FROM tickets WHERE order_id=?").all(o.id);
  const tickets=await Promise.all(ts.map(async t=>({ticketId:t.id,qr:await QR.toDataURL(t.qr_token)})));
  return res.json({...o,tickets});
 }
 res.json(o);
});
app.get("/health",(req,res)=>res.json({ok:true,service:"Nimoo Tickets"}));
const port=process.env.PORT||3000;app.listen(port,()=>console.log("Nimoo Tickets running on "+port));
