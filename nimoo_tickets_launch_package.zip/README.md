# Nimoo Tickets — launch package

This is a deployable Node.js starter for an event-ticket marketplace with a private admin dashboard and Safaricom Daraja STK Push integration.

## Included
- Public event catalogue
- Private admin login
- Create/publish event listings
- View orders and M-Pesa receipts
- M-Pesa STK Push checkout
- Payment callback handling
- QR ticket creation after a successful callback

## Important launch requirements
This package is not live until it is deployed to HTTPS hosting and configured with your own Safaricom Daraja credentials. Your customer-facing Buy Goods Till `6694836` is prefilled as `MPESA_TILL_NUMBER`. Safaricom's Daraja STK Push flow for a Till also requires the Safaricom-issued Head Office/Store shortcode in `MPESA_SHORTCODE`; the Till and API shortcode are not necessarily the same. A Till number alone is not enough to initiate or verify payments.

### 1. Prepare
- Use Node.js 20 or newer.
- Copy `.env.example` to `.env`.
- Set a strong unique `SESSION_SECRET` and `ADMIN_PASSWORD`.
- Set `BASE_URL` and `MPESA_CALLBACK_URL` to your real HTTPS domain.
- Add Daraja Consumer Key, Consumer Secret and Passkey from the Safaricom Daraja portal.
- Ask Safaricom for the Head Office/Store shortcode linked to Till 6694836, then set it as `MPESA_SHORTCODE`; keep `MPESA_TILL_NUMBER=6694836` and `MPESA_TRANSACTION_TYPE=CustomerBuyGoodsOnline`.

### 2. Run
```bash
npm install
cp .env.example .env
# edit .env with your own credentials
npm start
```
Open `http://localhost:3000`. Admin: `http://localhost:3000/admin.html`.

### 3. Go live
Deploy to a Node.js host that supports persistent disk storage (SQLite database/session files), configure environment variables in the host dashboard, and attach your domain with HTTPS. If the hosting provider uses ephemeral storage, migrate SQLite to managed persistent storage before launch.

### 4. Test safely
- Start with `MPESA_ENV=sandbox` and Safaricom test credentials.
- Test success, cancellation, timeout and duplicate callback scenarios.
- Switch to production only after Safaricom has approved the app and Till STK Push setup.
- Make a small controlled live test before public sales.

## Security and operational notes
- Never commit `.env` or expose Daraja secrets in browser code.
- Never ask customers for their M-Pesa PIN.
- The callback endpoint must be HTTPS and reachable publicly.
- Reconcile callback results against Daraja transaction records before treating orders as paid in a high-volume deployment. Add callback authentication/allowlisting, idempotency, monitoring, backups, email/SMS delivery, refunds and ticket scanning controls before scaling.
- The included QR codes are unique ticket tokens. Add a staff-only scan/validation endpoint before using QR codes for venue entry.
- Change seeded sample events and prices in the admin dashboard before publishing the site.
